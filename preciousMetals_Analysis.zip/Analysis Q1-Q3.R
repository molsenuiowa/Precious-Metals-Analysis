#Mike Olsen
#12/4/2023
#Project Analysis
#Data Wrangling Project
rm(list=ls())

# Load required libraries
library(dplyr)
library(ggplot2)
library(tidyr)
library(readr)
library(plotly)
library(reshape2)

#Q1 ANALYSIS - What is the correlation between gold and silver prices?

# Read the combined gold and silver dataset
combined_gold_silver_data <- read_csv("combined_gold_silver_data.csv")

# Convert column names to snake case
colnames(combined_gold_silver_data) <- make.names(colnames(combined_gold_silver_data), unique = TRUE)

# Print the modified column names
print(colnames(combined_gold_silver_data))

# Extract required variables
gold_silver_correlation_data <- combined_gold_silver_data %>%
  select(date, Adj.Close_gold, Adj.Close_SI)

# Calculate daily percentage change in closing prices, lag shifts values of the Adj.Close_gold by one time step (one day) which gets closing prices from the previous day
gold_silver_correlation_data <- gold_silver_correlation_data %>%
  mutate(percent_change_gold = (Adj.Close_gold - lag(Adj.Close_gold))/lag(Adj.Close_gold) * 100,
         percent_change_silver = (Adj.Close_SI - lag(Adj.Close_SI))/lag(Adj.Close_SI) * 100)

# Drop rows with NAs resulting from percentage change calculation
gold_silver_correlation_data <- na.omit(gold_silver_correlation_data)

# Calculate correlation between gold and silver prices
correlation_coefficient <- cor(gold_silver_correlation_data$percent_change_gold, gold_silver_correlation_data$percent_change_silver)

# Ensure the date column is in Date format for both datasets
gold_silver_correlation_data$date <- as.Date(gold_silver_correlation_data$date, format = "%m/%d/%Y")
combined_gold_silver_data$date <- as.Date(combined_gold_silver_data$date, format = "%m/%d/%Y")

# Visualization 1: Line plot of daily percentage change over time with improved date format
ggplot(gold_silver_correlation_data, aes(x = date)) +
  geom_line(aes(y = percent_change_gold, color = "Gold"), size = .75) +
  geom_line(aes(y = percent_change_silver, color = "Silver"), size = .75) +
  labs(title = "Line Plot of Daily Percentage Change in Gold and Silver Prices",
       x = "Date",
       y = "Percentage Change",
       color = "Commodity") +
  scale_color_manual(values = c("Gold" = "gold", "Silver" = "#C0C0C0")) +  # Use hexadecimal code for silver color
  theme_minimal()

# Data Preprocessing
combined_gold_silver_data$date <- as.Date(combined_gold_silver_data$date)

# Extract Month and Year from the 'date' column
combined_gold_silver_data$month_year <- format(combined_gold_silver_data$date, "%Y-%m")

# Filter data for Gold (GC=F) and Silver (SI=F)
gold_silver_volume_data <- combined_gold_silver_data %>%
  filter(ticker %in% c("GC=F", "SI=F"))

# Visualization 2: Density plot of daily percentage change
ggplot(gold_silver_correlation_data, aes(x = percent_change_gold, fill = "Gold")) +
  geom_density(alpha = 0.5) +
  geom_density(aes(x = percent_change_silver, fill = "Silver"), alpha = 0.5) +
  labs(title = "Density Plot of Daily Percentage Change in Gold and Silver Prices",
       x = "Percentage Change",
       fill = "Commodity") +
  scale_fill_manual(values = c("Gold" = "gold", "Silver" = "#C0C0C0")) +
  theme_minimal()

# Visualization 3: Boxplot of daily percentage change
ggplot(gold_silver_correlation_data, aes(x = "Commodity", y = percent_change_gold)) +
  geom_boxplot(fill = "gold", color = "black") +
  labs(title = "Boxplot of Daily Percentage Change in Gold and Silver Prices",
       x = "Commodity",
       y = "Percentage Change") +
  theme_minimal()





#Q2 Analysis - Volume

# Visualization 1: Monthly trading volumes for gold and silver
ggplot(gold_silver_volume_data, aes(x = month_year, y = volume, color = ticker)) +
  geom_point() +
  labs(title = "Monthly Trading Volumes for Gold and Silver",
       x = "Year-Month",
       y = "Trading Volume",
       color = "Commodity") +
  scale_color_manual(values = c("GC=F" = "gold", "SI=F" = "#C0C0C0")) +  # Use hexadecimal code for silver color
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))













#Q3 Analysis - How do the candlestick patterns for Gold and Silver, represented by open, high, low, and close prices, evolve over time? 

# Data Preprocessing
combined_gold_silver_data$date <- as.Date(combined_gold_silver_data$date)

# Candlestick Chart
install.packages("plotly")
library(plotly)

candlestick_data <- combined_gold_silver_data %>%
  filter(ticker %in% c("GC=F", "SI=F"))

candlestick_chart <- plot_ly(candlestick_data, type = "candlestick",
                             x = ~date,
                             open = ~open, close = ~close,
                             high = ~high, low = ~low,
                             color = ~ticker, colors = c("GC=F" = "gold", "SI=F" = "#C0C0C0"))

# Visualization
candlestick_chart %>%
  layout(title = "Candlestick Chart for Gold and Silver",
         xaxis = list(title = "Date"),
         yaxis = list(title = "Price"),
         showlegend = FALSE)




















