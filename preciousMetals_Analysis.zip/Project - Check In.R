# Install and load the required libraries
install.packages(c("dplyr", "readr"))
library(dplyr)
library(readr)

# Set the working directory
setwd("C:/Users/micha/Wrangling Project")

# Read the data files
gold_silver_data <- read_csv("gold_silver_2023_data.csv")
# Read the data from GC=F.csv
gold_data <- read.csv("GC=F.csv", colClasses = c("Date", "numeric"))

# Read the data from SI=F.csv
silver_data <- read.csv("SI=F.csv", colClasses = c("Date", "numeric"))

# Rename the "Date" column to "date" in gold_data
gold_data <- gold_data %>%
  rename(date = Date)

# Rename the "Date" column to "date" in silver_data
silver_data <- silver_data %>%
  rename(date = Date)

# Merge Gold data into gold_silver_data
gold_silver_data <- left_join(gold_silver_data, gold_data, by = "date", suffix = c("_gold", "_GC"))

# Merge Silver data into gold_silver_data
gold_silver_data <- left_join(gold_silver_data, silver_data, by = "date", suffix = c("_gold", "_SI"))

# Print or save the combined data
print(gold_silver_data)
write_csv(gold_silver_data, "combined_gold_silver_data.csv")

#Question 1: Correlation between Gold and Silver Prices

#Objective: Investigate the correlation between the daily adjusted closing prices of Gold and Silver to understand their historical price relationship.
#Variables Required: Adj Close_gold from Gold dataset and Adj Close_SI from Silver dataset.
#Complexity: Calculate and visualize the correlation, possibly exploring trends or patterns over time.

#Question 2: Seasonal Trends in Precious Metals Prices

#Objective: Explore whether there are seasonal trends in the combined prices of Gold and Silver by analyzing historical data.
#Variables Required: date, Adj Close_gold, Adj Close_SI, and potentially open, high, low, or volume from both Gold and Silver datasets.
#Complexity: Perform time-series analysis to identify and visualize potential seasonal patterns in precious metals prices.

#Question 3: Trading Volume Impact on Price Movements

#Objective: Investigate the relationship between trading volume and price movements for Gold and Silver to understand if higher trading volumes coincide with price changes.
#Variables Required: date, Adj Close_gold, Adj Close_SI, and volume from both Gold and Silver datasets.
#Complexity: Analyze and visualize the correlation between trading volumes and price changes over time, considering potential lag effects.